#version 330 compatibility

#include "/lib/common.glsl"

uniform sampler2D tex;
uniform float frameTimeCounter;
uniform mat4 gbufferModelView;

in vec2 vTexCoord;
in vec2 vLmCoord;
in vec4 vColor;
in vec3 vViewNormal;
in vec3 vWorldPos;
flat in int vBlockId;

/* DRAWBUFFERS:0126 */

vec3 getWaterWaveNormal(vec3 worldPos, float time) {
    vec2 p = worldPos.xz;
    float t = time * 1.65;

    float dHx = 0.0;
    float dHz = 0.0;

    float p1 = p.x * 1.4 + p.y * 0.8 + t;
    dHx += cos(p1) * 1.4 * 0.045;
    dHz += cos(p1) * 0.8 * 0.045;

    float p2 = p.x * 0.9 - p.y * 1.7 + t * 1.25;
    dHx += cos(p2) * 0.9 * 0.032;
    dHz -= cos(p2) * 1.7 * 0.032;

    float p3 = p.x * 3.1 + p.y * 2.6 - t * 1.8;
    dHx += cos(p3) * 3.1 * 0.012;
    dHz += cos(p3) * 2.6 * 0.012;

    // High-frequency micro-wave octave for sparkling sun/moon/lantern glints on water
    float p4 = p.x * 6.8 - p.y * 5.9 + t * 2.9;
    float p5 = p.x * 5.4 + p.y * 7.3 - t * 3.2;
    dHx += (cos(p4) * 6.8 - sin(p5) * 5.4) * 0.0045;
    dHz += (-cos(p4) * 5.9 + cos(p5) * 7.3) * 0.0045;

    dHx *= WATER_WAVE_STRENGTH;
    dHz *= WATER_WAVE_STRENGTH;

    return normalize(vec3(-dHx, 1.0, -dHz));
}

void main() {
    vec4 texSample = texture(tex, vTexCoord);
    vec4 albedo = texSample * vColor;

    if (albedo.a < 0.04) {
        discard;
    }

    vec3 viewNormal = normalize(vViewNormal);
    float smoothness = 0.88;
    float f0 = 0.05;
    float outAlpha = albedo.a;
    float matId = MAT_GLASS;
    vec3 pureTranslucentColor = albedo.rgb;

    if (vBlockId == 10008) {
        vec3 waveWorldNormal = getWaterWaveNormal(vWorldPos, frameTimeCounter);
        viewNormal = normalize(mat3(gbufferModelView) * waveWorldNormal);

        float waterLuma = getLuminance(albedo.rgb);
        albedo.rgb = mix(vec3(0.04, 0.20, 0.28), albedo.rgb * vec3(0.22, 0.62, 0.78), 0.35) * (0.65 + waterLuma * 0.7);
        pureTranslucentColor = albedo.rgb;
        outAlpha = 0.50;
        smoothness = 0.95;
        f0 = 0.05;
        matId = MAT_WATER;
    } else if (vBlockId == 10009) {
        // Stained Glass & Panes: enrich chromatic saturation and store pure unblended color in colortex6
        float luma = getLuminance(albedo.rgb);
        float maxC = max(albedo.r, max(albedo.g, albedo.b));
        vec3 normChroma = (maxC > 0.02) ? (albedo.rgb / maxC) : vec3(0.8);
        pureTranslucentColor = clamp(mix(vec3(getLuminance(normChroma)), normChroma, 1.45), vec3(0.04), vec3(1.0));
        albedo.rgb = clamp(mix(vec3(luma), albedo.rgb, 1.40), vec3(0.03), vec3(1.0));
        outAlpha = clamp(albedo.a * 0.65, 0.25, 0.72);
        smoothness = 0.90;
        f0 = 0.05;
        matId = MAT_STAINED_GLASS;
    } else {
        // Clear Glass, Translucent Ice, Slime, Honey
        smoothness = 0.88;
        f0 = 0.05;
        matId = MAT_GLASS;
    }

    gl_FragData[0] = vec4(albedo.rgb, outAlpha);
    gl_FragData[1] = vec4(encodeNormal(viewNormal), vLmCoord.x, vLmCoord.y);
    gl_FragData[2] = vec4(smoothness, f0, 0.0, matId);
    // Store pure unblended translucent color & alpha in colortex6 for stained glass optical filtering
    gl_FragData[3] = vec4(pureTranslucentColor, outAlpha);
}
